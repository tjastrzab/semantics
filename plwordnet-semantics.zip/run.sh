#!/bin/sh

# Prints usage information and exits
java -jar plwordnet-semantics.jar

# ***************************************************************
# Performs learning phase only on the input files given
# Assumes that input files are placed inside inputs directory

# Uncomment the line below to execute
# java -jar plwordnet-semantics.jar -l "inputs/test.txt"
# ***************************************************************

# ***************************************************************
# Performs classification phase only on the input files given
# Assumes that input files are placed inside inputs directory

# Uncomment the line below to execute
# java -jar plwordnet-semantics.jar -c "inputs/test.txt"
# ***************************************************************

# ***************************************************************
# Performs learning and classification phases on the files given
# Assumes that input files are placed inside inputs directory

# Uncomment the line below to execute
# java -jar plwordnet-semantics.jar -lc "inputs/test.txt"
# ***************************************************************
