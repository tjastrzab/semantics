What is included in this directory?

- 	config.properties			--	properties file. Specifies output directories and plWordNet queries.
-	inputs						--	input files
-	lib							--	libraries required by the project
- 	plwordnet-semantics.jar 	--	executable Java file
-	readme-first.txt			--	this manual
-	run.bat						--	batch file used for running the executable file (for Windows systems)
-	run.sh						--	batch file used for running the executable file (for Unix systems)

WARNING! The software was compiled under JDK version 1.8.0.45. To run it a JRE 1.8 is required.
WARNING! The software requires an Internet connection (unless the cache covers all specified examples).

How to use the software?

1.	Execute the run.bat (resp. run.sh) file -- open the command line (console) window and write ./run.bat (resp. ./run.sh). 

	By default a usage message will be printed on the console. 
	
2.	Edit run.bat (resp. run.sh) file contents by removing the comments where specified.

	Depending on the selected option(s) and input files the execution may take a few seconds up to several minutes.
	Appropriate messages will be printed at the beginning and end of execution. In case of an error a message will be 
	printed as well.
	
	If option -l has been selected the cache will be built (if it has not been built before) or it will be updated.
	If option -c has been selected the results of classification will be stored in the folder containing the input files.
	The name of result file will have '_classified' suffix.
	If option -lc has been selected both above cases apply.
	
WARNING! The name of the feature to learn and/or classify against has to match the name of the input file, 
e.g. 'test.txt' is the file for 'test' feature.

How to prepare an input file?

1.	First line of the file should contain the name of the feature preceded with #, e.g. #test.

2.	If the file is to be used for ranking building (learning phase), feature representatives should be placed on
	separate lines, without any additional markers in these lines. See words 'stolarz' and 'informatyk' in inputs/test.txt file.

3.	If the file is to be used for classification, the words should be placed on separate lines, with '+' or '-' markers at the 
	beginning of each line to specify whether the feature is expected to be described by the feature ('+' - positive) or not ('-' - negative).
	See words 'urzędnik' and 'pacjent' in inputs/test.txt file.